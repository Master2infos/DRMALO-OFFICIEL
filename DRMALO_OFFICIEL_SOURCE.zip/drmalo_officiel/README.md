# DRMALO OFFICIEL — base du projet Android Flutter

Cette archive contient une première base de code Flutter avec identité visuelle DRMALO, navigation mobile, récupération des articles WordPress publics, favoris locaux et compteur Tasbih persistant.

## Configuration requise
- Flutter SDK stable (Dart 3.3+)
- Android SDK / Android Studio
- Connexion Internet pour charger les publications du site

## Lancer le projet
```bash
flutter pub get
flutter run
```

## Générer un APK de test
```bash
flutter build apk --debug
```
Le fichier sera généré dans `build/app/outputs/flutter-apk/app-debug.apk`.

## Générer un APK release signé
Configurer d'abord une clé de signature Android (`key.properties` et `signingConfig` dans `android/app/build.gradle`), puis :
```bash
flutter build apk --release
```

## API WordPress
L'application lit les publications publiques via :
`https://www.drmalo.com/wp-json/wp/v2/posts`

La disponibilité réelle de cette route doit être confirmée sur l'hébergement DRMALO. Les contenus privés, types personnalisés (audios, vidéos, cours, livres) et taxonomies spécifiques peuvent nécessiter des routes ou extensions supplémentaires.

## État de cette livraison
Ceci est un **prototype de départ / socle technique**, pas encore une application complète prête à publier. Les écrans Coran/audio, calcul fiable des horaires, calcul géographique de la Qibla, calendrier hégirien, adhkar, téléchargements hors ligne, notifications, authentification et administration restent à développer et tester. Le code source seul ne constitue pas un APK compilé.

Aucun mot de passe WordPress, clé privée Firebase ou secret d'administration ne doit être intégré dans l'application Android.
