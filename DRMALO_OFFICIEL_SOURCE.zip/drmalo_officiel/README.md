# DRMALO OFFICIEL — projet Flutter Android

Application Android adaptative téléphone/tablette, identité visuelle DRMALO (vert et or), avec :
- navigation mobile en bas et navigation latérale sur grands écrans ;
- publications publiques WordPress (lecture seule) ;
- favoris et compteur Tasbih conservés localement ;
- horaires de prière via AlAdhan après autorisation GPS (méthode ISNA actuellement configurée) ;
- direction de la Qibla calculée à partir du GPS et du capteur boussole ;
- liste des 114 sourates et affichage arabe + traduction française via AlQuran Cloud ;
- date hégirienne via AlAdhan.

## Pré-requis
- Flutter stable avec Dart 3.3 ou supérieur ;
- Android Studio et Android SDK ;
- accès Internet sur l'appareil pour les services en ligne.

## Générer les fichiers Android manquants
L'archive de travail ne contient pas encore l'intégralité du squelette Gradle/Gradle Wrapper créé par Flutter. Dans le dossier du projet, avec Flutter installé, exécuter :

```bash
rm -rf android
flutter create --platforms=android --org com.drmalo --project-name drmalo_officiel .
```

Puis remplacer `android/app/src/main/AndroidManifest.xml` par le manifeste fourni dans cette archive (il déclare Internet et localisation GPS). Vérifier que l'identifiant d'application et le nom de package conviennent avant publication.

## Installer en mode développement

```bash
flutter pub get
flutter run
```

## Construire un APK de test

```bash
flutter build apk --debug
```

Sortie : `build/app/outputs/flutter-apk/app-debug.apk`.

## Construire un APK de production

Créer une clé de signature privée et configurer `key.properties` ainsi que `signingConfig` dans `android/app/build.gradle` avant de lancer :

```bash
flutter build apk --release
```

Ne jamais partager la clé privée ou le fichier `key.properties`. Sortie habituelle : `build/app/outputs/flutter-apk/app-release.apk`.

## Connexion WordPress

La lecture des articles publics utilise `https://www.drmalo.com/wp-json/wp/v2/posts`. L'accès à cette route n'a pas pu être vérifié depuis l'environnement de préparation. Si DRMALO utilise WordPress.com sans fonctionnalités d'hébergement activées, l'URL REST peut être différente. Vérifier la racine `/wp-json/` du site et adapter `lib/services/wordpress_service.dart` si nécessaire.

Les audios, vidéos, cours, PDF, catégories personnalisées et autres types de contenus ne sont pas encore reliés : il faut confirmer leurs types et routes REST WordPress. Aucun identifiant administrateur ni secret ne doit être intégré à l'APK.

## Limites de cette version

Cette livraison est un **prototype fonctionnel avancé / MVP source**, pas encore une version finale validée pour diffusion. Les services horaires, Coran et calendrier nécessitent Internet. La méthode de calcul des prières est actuellement réglée sur ISNA et devra être confirmée selon la préférence locale. La précision de la Qibla dépend du GPS, du capteur magnétique et du calibrage de l'appareil.

À terminer avant une publication :
- tests de compilation et tests réels sur plusieurs téléphones/tablettes Android ;
- traduction complète et sélecteur effectif français/arabe/anglais (les libellés sont encore majoritairement en français) ;
- lecture audio/récitation, téléchargements hors ligne et gestion des fichiers ;
- notifications Adhan/rappels ;
- pages de détails WordPress et intégration des médias/catégories DRMALO ;
- synchronisation cloud / authentification Firebase si souhaitée ;
- tests de sécurité, accessibilité, politique de confidentialité et signature release.

Le SDK Flutter/Android n'était pas disponible dans l'environnement de génération : aucun APK n'a donc été compilé ni testé ici.
