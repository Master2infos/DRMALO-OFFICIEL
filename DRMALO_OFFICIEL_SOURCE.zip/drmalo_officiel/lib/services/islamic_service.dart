import 'dart:convert';
import 'dart:math' as math;
import 'package:geolocator/geolocator.dart';
import 'package:http/http.dart' as http;

class IslamicService {
  static const _aladhan = 'https://api.aladhan.com/v1';
  static const _quran = 'https://api.alquran.cloud/v1';

  Future<Position> currentPosition() async {
    if (!await Geolocator.isLocationServiceEnabled()) {
      throw Exception('Activez la localisation GPS.');
    }
    var permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
    }
    if (permission == LocationPermission.denied || permission == LocationPermission.deniedForever) {
      throw Exception('Autorisation de localisation refusée.');
    }
    return Geolocator.getCurrentPosition();
  }

  Future<Map<String, dynamic>> prayerTimes(Position position, DateTime date) async {
    final stamp = '${date.day}-${date.month}-${date.year}';
    final uri = Uri.parse('$_aladhan/timings/$stamp').replace(queryParameters: {
      'latitude': '${position.latitude}', 'longitude': '${position.longitude}', 'method': '2',
    });
    final response = await http.get(uri).timeout(const Duration(seconds: 20));
    if (response.statusCode != 200) throw Exception('Service des horaires indisponible.');
    final json = jsonDecode(response.body) as Map<String, dynamic>;
    if (json['code'] != 200) throw Exception('Réponse invalide du service des horaires.');
    return json['data'] as Map<String, dynamic>;
  }

  Future<List<dynamic>> surahs() async {
    final response = await http.get(Uri.parse('$_quran/surah')).timeout(const Duration(seconds: 20));
    if (response.statusCode != 200) throw Exception('Impossible de charger les sourates.');
    return (jsonDecode(response.body)['data'] as List).cast<dynamic>();
  }

  Future<Map<String, dynamic>> surah(int number) async {
    final response = await http.get(Uri.parse('$_quran/surah/$number/editions/quran-uthmani,fr.hamidullah')).timeout(const Duration(seconds: 20));
    if (response.statusCode != 200) throw Exception('Impossible de charger cette sourate.');
    final data = jsonDecode(response.body)['data'] as List;
    return {'arabic': data[0], 'french': data.length > 1 ? data[1] : null};
  }

  Future<Map<String, dynamic>> hijriDate(DateTime date) async {
    final stamp = '${date.day}-${date.month}-${date.year}';
    final response = await http.get(Uri.parse('$_aladhan/gToH/$stamp')).timeout(const Duration(seconds: 20));
    if (response.statusCode != 200) throw Exception('Calendrier hégirien indisponible.');
    return jsonDecode(response.body)['data']['hijri'] as Map<String, dynamic>;
  }

  static double qiblaBearing(double latitude, double longitude) {
    const kaabaLat = 21.422487 * math.pi / 180;
    const kaabaLon = 39.826206 * math.pi / 180;
    final lat = latitude * math.pi / 180;
    final lon = longitude * math.pi / 180;
    final dLon = kaabaLon - lon;
    final y = math.sin(dLon);
    final x = math.cos(lat) * math.tan(kaabaLat) - math.sin(lat) * math.cos(dLon);
    return (math.atan2(y, x) * 180 / math.pi + 360) % 360;
  }
}
