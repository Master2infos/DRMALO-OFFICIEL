import 'package:shared_preferences/shared_preferences.dart';

class LocalStore {
  static const _favoritesKey = 'favorite_post_ids';
  static const _tasbihKey = 'tasbih_count';
  static Future<Set<String>> favorites() async => (await SharedPreferences.getInstance()).getStringList(_favoritesKey)?.toSet() ?? {};
  static Future<void> toggleFavorite(String id) async {
    final prefs = await SharedPreferences.getInstance();
    final items = (prefs.getStringList(_favoritesKey) ?? []).toSet();
    items.contains(id) ? items.remove(id) : items.add(id);
    await prefs.setStringList(_favoritesKey, items.toList());
  }
  static Future<int> tasbihCount() async => (await SharedPreferences.getInstance()).getInt(_tasbihKey) ?? 0;
  static Future<int> incrementTasbih() async {
    final prefs = await SharedPreferences.getInstance();
    final next = (prefs.getInt(_tasbihKey) ?? 0) + 1;
    await prefs.setInt(_tasbihKey, next);
    return next;
  }
  static Future<void> resetTasbih() async => (await SharedPreferences.getInstance()).setInt(_tasbihKey, 0);
}
