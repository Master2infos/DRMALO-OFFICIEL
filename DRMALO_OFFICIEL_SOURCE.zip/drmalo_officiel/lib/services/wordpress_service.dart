import 'dart:convert';
import 'package:http/http.dart' as http;

/// Public WordPress content reader. No admin password or secret belongs in the APK.
class WordPressService {
  static const String baseUrl = 'https://www.drmalo.com/wp-json/wp/v2';

  Future<List<Map<String, dynamic>>> fetchPosts({int page = 1, int perPage = 20}) async {
    final uri = Uri.parse('$baseUrl/posts').replace(queryParameters: {
      '_embed': '1', 'page': '$page', 'per_page': '$perPage',
    });
    final response = await http.get(uri, headers: {'Accept': 'application/json'});
    if (response.statusCode != 200) {
      throw Exception('API WordPress indisponible (${response.statusCode}).');
    }
    final data = jsonDecode(response.body);
    if (data is! List) return [];
    return data.cast<Map<String, dynamic>>();
  }

  Future<List<Map<String, dynamic>>> searchPosts(String query) async {
    final uri = Uri.parse('$baseUrl/search').replace(queryParameters: {'search': query, 'per_page': '20'});
    final response = await http.get(uri);
    if (response.statusCode != 200) throw Exception('Recherche indisponible.');
    final data = jsonDecode(response.body);
    return data is List ? data.cast<Map<String, dynamic>>() : [];
  }

  String plainText(String html) => html.replaceAll(RegExp(r'<[^>]*>'), ' ').replaceAll('&nbsp;', ' ').trim();
}
