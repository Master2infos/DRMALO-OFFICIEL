import 'package:flutter/material.dart';
import '../widgets/section_title.dart';
import 'content_screen.dart';
import 'quran_screen.dart';
import 'qibla_screen.dart';
import 'calendar_screen.dart';
import 'tasbih_screen.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});
  @override Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(18), children: [
    Row(children: [ClipRRect(borderRadius: BorderRadius.circular(18), child: Image.asset('assets/images/drmalo_logo.png', width: 64, height: 64, fit: BoxFit.cover)), const SizedBox(width: 12), const Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('السلام عليكم', style: TextStyle(fontSize: 17, fontWeight: FontWeight.bold)), Text('DRMALO OFFICIEL', style: TextStyle(fontSize: 21, fontWeight: FontWeight.w900, color: Color(0xFF087A50))), Text('Votre compagnon islamique')]))]),
    const SizedBox(height: 20),
    Container(padding: const EdgeInsets.all(20), decoration: BoxDecoration(gradient: const LinearGradient(colors: [Color(0xFF07583D), Color(0xFF0C9562)]), borderRadius: BorderRadius.circular(24)), child: const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('PROCHAINE PRIÈRE', style: TextStyle(color: Colors.white70, letterSpacing: 1)), SizedBox(height: 8), Text('Horaires de prière', style: TextStyle(color: Colors.white, fontSize: 25, fontWeight: FontWeight.bold)), SizedBox(height: 5), Text('Configurez votre ville et votre méthode de calcul dans les paramètres.', style: TextStyle(color: Colors.white))])),
    const SizedBox(height: 20), const SectionTitle('Accès rapide'),
    GridView.count(shrinkWrap: true, physics: const NeverScrollableScrollPhysics(), crossAxisCount: 2, crossAxisSpacing: 12, mainAxisSpacing: 12, childAspectRatio: 1.65, children: [
      _QuickTile(Icons.menu_book, 'Saint Coran', 'Lecture & traduction', () => Navigator.push(context, MaterialPageRoute(builder: (_) => const QuranScreen()))),
      _QuickTile(Icons.explore, 'Direction Qibla', 'Trouver La Mecque', () => Navigator.push(context, MaterialPageRoute(builder: (_) => const QiblaScreen()))),
      _QuickTile(Icons.calendar_month, 'Calendrier', 'Dates hégiriennes', () => Navigator.push(context, MaterialPageRoute(builder: (_) => const CalendarScreen()))),
      _QuickTile(Icons.fingerprint, 'Tasbih', 'Compteur de dhikr', () => Navigator.push(context, MaterialPageRoute(builder: (_) => const TasbihScreen()))),
    ]),
    const SectionTitle('À la une sur DRMALO'),
    Card(child: ListTile(leading: const Icon(Icons.play_circle_fill, color: Color(0xFF087A50), size: 38), title: const Text('Cours, conférences et enseignements'), subtitle: const Text('Retrouvez les dernières publications du site DRMALO.'), trailing: const Icon(Icons.chevron_right), onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const ContentScreen())))),
  ]);
}
class _QuickTile extends StatelessWidget { const _QuickTile(this.icon, this.title, this.sub, this.onTap); final IconData icon; final String title, sub; final VoidCallback onTap; @override Widget build(BuildContext context) => Card(elevation: 0, child: InkWell(onTap: onTap, borderRadius: BorderRadius.circular(14), child: Padding(padding: const EdgeInsets.all(12), child: Row(children: [Icon(icon, color: const Color(0xFF087A50), size: 27), const SizedBox(width: 10), Expanded(child: Column(mainAxisAlignment: MainAxisAlignment.center, crossAxisAlignment: CrossAxisAlignment.start, children: [Text(title, style: const TextStyle(fontWeight: FontWeight.bold)), Text(sub, style: Theme.of(context).textTheme.bodySmall)]))])))); }
