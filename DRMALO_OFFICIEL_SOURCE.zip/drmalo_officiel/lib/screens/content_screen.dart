import 'package:flutter/material.dart';
import '../services/wordpress_service.dart';
import '../services/local_store.dart';

class ContentScreen extends StatefulWidget { const ContentScreen({super.key}); @override State<ContentScreen> createState() => _ContentScreenState(); }
class _ContentScreenState extends State<ContentScreen> {
  final api = WordPressService(); late Future<List<Map<String,dynamic>>> future;
  @override void initState() { super.initState(); future = api.fetchPosts(); }
  @override Widget build(BuildContext context) => Scaffold(appBar: AppBar(title: const Text('Espace DRMALO'), actions: [IconButton(onPressed: () => setState(() => future = api.fetchPosts()), icon: const Icon(Icons.refresh))]), body: FutureBuilder(future: future, builder: (context, snapshot) {
    if (snapshot.connectionState == ConnectionState.waiting) return const Center(child: CircularProgressIndicator());
    if (snapshot.hasError) return Center(child: Padding(padding: const EdgeInsets.all(24), child: Column(mainAxisSize: MainAxisSize.min, children: [const Icon(Icons.cloud_off, size: 48), const SizedBox(height: 12), const Text('Impossible de charger les contenus DRMALO pour le moment.'), const SizedBox(height: 8), Text('${snapshot.error}', textAlign: TextAlign.center), TextButton(onPressed: () => setState(() => future = api.fetchPosts()), child: const Text('Réessayer'))])));
    final posts = snapshot.data ?? [];
    if (posts.isEmpty) return const Center(child: Text('Aucune publication disponible.'));
    return ListView.builder(padding: const EdgeInsets.all(12), itemCount: posts.length, itemBuilder: (context, i) { final p = posts[i]; final id = '${p['id']}'; final title = api.plainText(p['title']?['rendered'] ?? 'Sans titre'); final excerpt = api.plainText(p['excerpt']?['rendered'] ?? ''); return Card(child: ListTile(title: Text(title, maxLines: 2, overflow: TextOverflow.ellipsis), subtitle: Text(excerpt, maxLines: 3, overflow: TextOverflow.ellipsis), trailing: IconButton(icon: const Icon(Icons.bookmark_add_outlined), onPressed: () async { await LocalStore.toggleFavorite(id); if (context.mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Favori enregistré sur cet appareil.'))); }))); });
  }));
}
