import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:flutter_compass/flutter_compass.dart';
import 'package:geolocator/geolocator.dart';
import '../services/islamic_service.dart';

class QiblaScreen extends StatefulWidget { const QiblaScreen({super.key}); @override State<QiblaScreen> createState()=>_QiblaScreenState(); }
class _QiblaScreenState extends State<QiblaScreen> { double? bearing; String? error;
 @override void initState(){super.initState(); locate();}
 Future<void> locate() async { try { final p=await IslamicService().currentPosition(); if(mounted)setState(()=>bearing=IslamicService.qiblaBearing(p.latitude,p.longitude)); } catch(e){if(mounted)setState(()=>error=e.toString());} }
 @override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:const Text('Direction de la Qibla')),body:Center(child:Padding(padding:const EdgeInsets.all(24),child:Column(mainAxisAlignment:MainAxisAlignment.center,children:[const Text('Orientez le téléphone à plat et éloignez-le des objets métalliques.',textAlign:TextAlign.center),const SizedBox(height:24),StreamBuilder<CompassEvent>(stream:FlutterCompass.events,builder:(context,snapshot){final heading=snapshot.data?.heading;if(bearing==null||heading==null)return Column(children:[const Icon(Icons.explore_off,size:90),Text(error??'Recherche de la position ou boussole indisponible.'),TextButton(onPressed:locate,child:const Text('Réessayer'))]); final relative=(bearing!-heading+360)%360;return Column(children:[Transform.rotate(angle:relative*math.pi/180,child:const Icon(Icons.navigation,size:150,color:Color(0xFF087A50))),const SizedBox(height:18),Text('${bearing!.toStringAsFixed(0)}°',style:const TextStyle(fontSize:38,fontWeight:FontWeight.bold)),const Text('Direction de La Mecque')]);})])))); }
