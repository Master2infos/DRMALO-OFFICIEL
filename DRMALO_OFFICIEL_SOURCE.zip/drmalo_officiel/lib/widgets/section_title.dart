import 'package:flutter/material.dart';
class SectionTitle extends StatelessWidget {
  const SectionTitle(this.title, {super.key, this.trailing});
  final String title; final Widget? trailing;
  @override Widget build(BuildContext context) => Padding(padding: const EdgeInsets.only(bottom: 12, top: 8), child: Row(children: [Expanded(child: Text(title, style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.bold))), if (trailing != null) trailing!]));
}
