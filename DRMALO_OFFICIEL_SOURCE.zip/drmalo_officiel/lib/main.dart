import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'screens/app_shell.dart';

void main() => runApp(const DrmaloApp());

class DrmaloApp extends StatelessWidget {
  const DrmaloApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    debugShowCheckedModeBanner: false,
    title: 'DRMALO OFFICIEL',
    supportedLocales: const [Locale('fr'), Locale('ar'), Locale('en')],
    localizationsDelegates: GlobalMaterialLocalizations.delegates,
    theme: ThemeData(useMaterial3: true, colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF087A50), brightness: Brightness.light), scaffoldBackgroundColor: const Color(0xFFF5F8F5), fontFamily: 'Roboto'),
    darkTheme: ThemeData(useMaterial3: true, colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF087A50), brightness: Brightness.dark)),
    home: const AppShell(),
  );
}
